Membership缺endDate
Order缺pointCharge（随便数字是几百的数字就好了）
Rent_Car里rentBy应该是人名
Public_Equipment_Repair里缺record

**********************************
上述内容已修改

rent_car中 rent_by写的是会员号
个人认为会员不需要有有效期时间限制，目前统一的时间限制是2030年12月31日 
rent_car里的车型我是查了一个数据库调出来的数据 结果刚才查了一下车又老又丑
order中目前customer写的是名字 不知道合适否 也许应该写某id 比如member id 所有顾客免费默认加入member

**********************************
Buses里VIN重复
Maintains里reusable应为0或1

Buses里carType应为巴士型号
日期格式应为YYYY-MM-DD

unique暂时删掉，因为input的data有问题



12.12 修改了时间格式为yyyy-mm-dd 但是用excel打开的时候会自动识别成时间格式，看起来是/，用txt打开就能看到它原来就是-, 如果不是，用ctrl+h修改。 修改了rentcar的主键为order_no，相当于记录历史记录的表，rentby后面是会员号。 maintains表修改了reusable和cost。 

ORDER表中记录customers的那一列改成了customer_ssn，外键必须是其他表的unique约束列 或者 主键。名字不能unique

**********************************
Order表应为Orders表，要有s，已修改
Order表修改的customer_ssn没有在database_table.py中修改，已修改
Rent_Car表列顺序错误，orderNo应在第一列，已修改

**********************************
Rent_Car表中rentDate、returnDate时间格式应为YYYY-MM-DD
若有时间，将Customer表和Staff表中Gender换为F、M（大写字母）
没时间就不换了