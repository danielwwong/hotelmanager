# hotelmanager

## Use Flask
### Activate: source ./venv/bin/activate
### Deactivate: type "deactivate"

## Flask-Script
### Type: pip install flask-script
### Type exit() or use Ctrl+Z then press Return to exit from Python command line

## Data Type
### ![image](http://github.com/danielwwong/hotelmanager/raw/master/screenshots/screen_shot_1.png)
### ![image](http://github.com/danielwwong/hotelmanager/raw/master/screenshots/screen_shot_2.png)